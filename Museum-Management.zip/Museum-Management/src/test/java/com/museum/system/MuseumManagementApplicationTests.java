package com.museum.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuseumManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
