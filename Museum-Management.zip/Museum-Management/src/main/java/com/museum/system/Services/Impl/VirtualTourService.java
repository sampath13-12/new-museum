package com.museum.system.Services.Impl;

import com.museum.system.Services.IVirtualTourService;

public class VirtualTourService implements IVirtualTourService {
}
