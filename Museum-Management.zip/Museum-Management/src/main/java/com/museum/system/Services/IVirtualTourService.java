package com.museum.system.Services;

public interface IVirtualTourService {
}
