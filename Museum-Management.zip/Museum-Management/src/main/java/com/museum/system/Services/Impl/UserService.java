package com.museum.system.Services.Impl;

import com.museum.system.Services.IUserService;

public class UserService implements IUserService {
}
