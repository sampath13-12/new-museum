package com.museum.system.Services.Impl;

import com.museum.system.Services.IAdmissionService;

public class AdmissionService implements IAdmissionService {
}
