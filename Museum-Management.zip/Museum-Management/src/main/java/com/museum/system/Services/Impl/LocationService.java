package com.museum.system.Services.Impl;

import com.museum.system.Services.ILocationService;

public class LocationService implements ILocationService {
}
