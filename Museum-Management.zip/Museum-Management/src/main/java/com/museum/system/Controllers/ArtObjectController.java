package com.museum.system.Controllers;

public class ArtObjectController {
}
