package com.museum.system.Services.Impl;

import com.museum.system.Services.IRestorationLogService;

public class RestorationLogService implements IRestorationLogService {
}
