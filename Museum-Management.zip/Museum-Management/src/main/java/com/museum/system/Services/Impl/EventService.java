package com.museum.system.Services.Impl;

import com.museum.system.Services.IEventService;

public class EventService implements IEventService {
}
