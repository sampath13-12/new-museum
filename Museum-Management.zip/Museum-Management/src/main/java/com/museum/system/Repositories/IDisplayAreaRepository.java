package com.museum.system.Repositories;

import com.museum.system.Entities.DisplayArea;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IDisplayAreaRepository extends JpaRepository<DisplayArea, Long> {
}
