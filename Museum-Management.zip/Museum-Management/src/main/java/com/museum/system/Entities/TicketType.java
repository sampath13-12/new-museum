package com.museum.system.Entities;

public enum TicketType {
    SINGLE,
    SEASON,
    SPECIAL_EVENT
}
