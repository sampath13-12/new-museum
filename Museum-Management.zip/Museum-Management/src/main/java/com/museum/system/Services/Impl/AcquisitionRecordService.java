package com.museum.system.Services.Impl;

import com.museum.system.Services.IAcquisitionRecordService;
import org.springframework.stereotype.Service;

@Service
public class AcquisitionRecordService implements IAcquisitionRecordService {
}
