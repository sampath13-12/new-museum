package com.museum.system.Services.Impl;

import com.museum.system.Services.IPatronService;

public class PatronService implements IPatronService {
}
