package com.museum.system.Services.Impl;

import com.museum.system.Services.ILoanContractService;

public class LoanContractService implements ILoanContractService {
}
